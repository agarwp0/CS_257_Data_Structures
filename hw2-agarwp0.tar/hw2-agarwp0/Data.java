/* Pravesh Agarwal
 * Feb 6, Thursday, 2020
 * HW2, Q1 Exercise 3 of Chapter 7 found on p.273
 * Construcing a enum type of months in a year.
 * HW2, Q1 Exercise 4 of Chapter 7 found on p.273
 * Construcing a data class that initializes dates in MDY or DMY form.
 */


enum Month{

  JANUARY
  , FEBRUARY
  , MARCH
  , APRIL
  , MAY
  , JUNE
  , JULY
  , AUGUST
  , SEPTEMBER
  , OCTOBER
  , NOVEMBER
  , DECEMBER

}

public class data{

  private int dd, yyyy;
  private Month mm
  
  public void data(){
    dd = 1;
    yyyy = 1900;
    mm = Month.JANUARY;
  }

  public void data(Month mm, int dd, int yyyy){
    this.dd = dd;
    this.mm=mm;
    this.yyyy=yyyy;
  }

  public void data(int dd, Month mm, int yyyy){
    this(mm, dd, yyyy);
  }

  public int getDay(){
    return dd;
  }

  public Month getMonth(){
    return mm;
  }
  
  public int getYear(){
    return yyyy;
  }

  public String toString(){
     return dd+"-"+mm.subString(0,2)+yyyy;
  }


}
