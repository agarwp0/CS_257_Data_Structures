/* Pravesh Agarwal
 * hw2 Feb 17, 2020
 * Draws a checkers in a JFrame with Java Graphics (not object oriented)
 */

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComponent;
import java.awt.Color;
import java.awt.Graphics;

public class Checkers extends JComponent{

  private Graphics g;

  public static void main(String[] args){
    JFrame frame = new JFrame("Checkers");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(800, 800);
    frame.setBackground(Color.LIGHT_GRAY);
    frame.setVisible(true);
    
    // JPanel is a light weight container
    JPanel panel = new JPanel() {
      
      @Override
      public void paintComponent(Graphics g){
        super.paintComponent(g);
        
	// Constructing the checker board
        int x = 10, y = 10, w = 90, h = 90;
        int noOfRects = 8;
    
        for(int i = 0; i<noOfRects; i++){
          for(int j = 0; j<noOfRects; j++){
            if( (i+j) % 2 == 0){
  	      g.setColor(Color.BLACK);
	    }
            else {
              g.setColor(Color.WHITE);
	    }
            g.fillRect(x, y, w, h);

	    x += w;
          }
          y += h;
          x = x-w*noOfRects;
        } 


	// Constructing the red checker (P)ieces 
        x = y = 10;
	w = h = 90;
        noOfRects = 8;
	int  diff = 20;
    
        for(int i = 0; i< noOfRects-2; i++){
          for(int j = 0; j<noOfRects; j++){
  	    g.setColor(Color.RED);
            if( (i+j) % 2 == 0){
              g.fillOval(x+diff/2, y+diff/2, w-diff, h-diff);
	    }

	    x += w;
          }
          y += h;
          x = x-w*noOfRects;
	  if(i == 2) 
	    y += 2*h;
        } 

      }
    
    };

    frame.add(panel);
 
    // because added panel after setVisible was called  
    frame.validate();
    frame.repaint();
  
  
  
  }


}

