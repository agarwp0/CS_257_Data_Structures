/* Pravesh Agarwal
 * Feb 9, Sun, 2020
 * HW2 Q2 Exercise 9 of chaper 7 found on pg 277
 * Class with a construction that has raindom int generator
 * and random double generator methods
 */



public class Random{

  // Uses default constructor

  // Random Int Generator Method
  public int RIG(int min, int max){
    int diff = max-min;
    double random = Math.random();
    if (random >0.945) random = Math.round(random);
    return (int) (random*diff) + min;
  }

  // Random Double Generator
  public double RDG(int min, int max){
    int diff = max-min;
    double random = Math.random();
    return (random*diff) + min;
  }

}
