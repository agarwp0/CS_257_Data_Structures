/* Pravesh Agarwal
 * Feb 6, Thursday, 2020
 * HW2, Q1 Exercise 4 of Chapter 7 found on p.273
 * Construcing a Date class that initializes dates in MDY or DMY form.
 */

import java.util.Stack;

public class DateTest_Client{


  public static void main(String[] args){
	  
    DateStack date = new DateStack(new Date(Month.JUNE, 4, 1998)
		                  ,new Date(Month.JULY, 4, 1988)
				  ,new Date(4, Month.JUNE, 1998));
     
    System.out.printf("%s", date.toString());


    Date d =new Date(Month.JUNE, 4, 1998);
    System.out.printf("\n%s\n", d.toString());



  }


}
