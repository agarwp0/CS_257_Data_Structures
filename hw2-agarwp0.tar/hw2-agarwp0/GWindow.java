import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;

public class GWindow extends JFrame{

  public GWindow (){
    this( new GCanvas() );
  }

  public GWindow (int w, int h){
    this( new GCanvas(w, h) );
    this.w = w;
    this.h = h;
  }

  public GWindow (GCanvas gc){
    String title = System.getProperty( "sun.java.command" );
    setTitle( 
              title==null ? "Graphics Window" 
                            :
                            title.substring(title.lastIndexOf('.')+1)
            );
    setBackground(Color.WHITE);
    this.gc = gc;
    add(gc);
    pack();
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true);
  }


  public void add(GObject gob){ gc.add(gob); }
  public int getWidth()       { return w;    }
  public int getHeight()      { return h;    }
  public GCanvas getCanvas()  { return gc;   } 

  private GCanvas gc;
  private int w,h;

}
