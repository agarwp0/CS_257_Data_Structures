/* HW2, Q1 Exercise 3 of Chapter 7 found on p.273
 * Construcing a enum type of months in a year.
 */



public enum Month{

  JANUARY
  , FEBRUARY
  , MARCH
  , APRIL
  , MAY
  , JUNE
  , JULY
  , AUGUST
  , SEPTEMBER
  , OCTOBER
  , NOVEMBER
  , DECEMBER;

  // Get the first 3 characters with first char in UpperCase
  @Override
  public String toString(){
    String s = Character.toString( 
	       Character.toUpperCase( this.name().charAt(0) ) );
    s = s + this.name().substring(1,3).toLowerCase();
    return s;
  }

}

