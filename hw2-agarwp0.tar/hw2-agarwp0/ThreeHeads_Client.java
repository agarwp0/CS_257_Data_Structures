/* Pravesh Agarwal
 * Feb 9, Sun, 2020
 * HW2 Q2 Exercise 9 of chaper 7 found on pg 277
 * the program simulates flipping a coin till three consectutive heads
 * displays the total number of coin flips that were made.
 * It uses the class Random.
 */

import java.util.ArrayList;

public class ThreeHeads_Client{

  private static ArrayList<Integer> results = new ArrayList<Integer>(20);

  public static void main(String[] args){

    // flipping coin till we get three heads
    int noHeads = 0;
    int count = 0;
    while(noHeads != 3){  
      results.add( Coin(0, 1) );
      noHeads = (results.get(count) == 1) ?  noHeads+1 : 0;
      count++;
    }
    
    // Printing heads or tails
    for(int result : results)    
      if(result == 0){
        System.out.printf("\n%s\n","tails");
      }
      else{ 
        System.out.printf("\n%s\n","heads");
      }
  

    System.out.printf("\nIt took %d flips to get 3 consecutive heads\n"
		    ,count);
  }


  public static int Coin(int min, int max){
    Random r = new Random();
    double value = r.RDG(min, max);
    int result = (value >0.495) ? (int) Math.round(value): (int) value;
    return result;
  }





}
