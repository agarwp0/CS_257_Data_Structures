/* Pravesh Agarwal
 * hw2 Feb 17, 2020
 * Using constructed class GString to make the string go in spiral using
 * recursion but that didn't work so just submitting in iteration
 * But I have also submitted the recursive file 
 * please help me look what went wrong. Thank you!
 */

import java.awt.Color;
import java.util.Scanner;

public class SpiralText_Client1 extends WC{


  private GFilledOval theOval;
  private GString theString;
  private String s="this is a string"; 
  private int n;

  public void begin(){
    n =  s.length(); 
    spiralText( s , 300, 300,5, 20 );
  }
  
  public static void main (String[]args) {
    Scanner scan = new Scanner(System.in);
    System.out.printf("\nEnter 'A' sentence.\n");
  
    String s = scan.nextLine();

    SpiralText_Client1 object = new SpiralText_Client1();
    
    // why doesn't this work?
    object.s = s;

    new SpiralText_Client1().startController(1000,1000);
  }

  public void spiralText(String s, int x, int y,int diff, int size){
    
    for(int i = 0; i<n; i++){
      String st = Character.toString( s.charAt(i) );
      if(i<n/4){
        new GString(st, x, y, size, canvas);
        x= x+diff+size;
	y= y+diff+size;
	diff +=2;
      }
      else if(i<n/2){
        new GString(st, x, y, size, canvas);
        x= x-diff-size;
	y= y+diff+size;
	diff +=2;
      }
      else if(i<3*n/4){
        new GString(st, x, y, size, canvas);
        x= x-diff-size;
	y= y-diff-size;
	diff += 2;
      }
      else{
        new GString(st, x, y, size, canvas);
        x= x+diff+size;
	y= y-diff-size;
	diff +=2;
      }
    }
	  
  }

/*
  public void onMousePress(Location p){
    int r = (int)(255*Math.random());
    int g = (int)(255*Math.random());
    int b = (int)(255*Math.random());
    theString.setColor(  new Color(r,g,b) );
  }
*/

}
