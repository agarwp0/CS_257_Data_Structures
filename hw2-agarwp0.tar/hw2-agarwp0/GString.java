import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;

public class GString extends GObject {

  public GString (String s, double x, double y, double w, GWindow dc){
    moveTo(x,y);
    setSize(w);
    this.s = s;
    dc.add(this);
  }
  
  public GString (String s, double x, double y, GWindow dc){
    this(s,x,y,10,dc);
  }

  public void paint(Graphics g){
    g.setColor(color);
    g.setFont(new Font("TimesRoman", Font.PLAIN,(int) width) );
    g.drawString(s, (int)x, (int)y);
  }

  public void setSize(double w){
    this.width = w;
    repaint();
  }

  protected double width;
  protected String s;
}
