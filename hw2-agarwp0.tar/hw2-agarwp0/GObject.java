import java.awt.Color;
import java.awt.Graphics;

public abstract class GObject {

  public abstract void paint(Graphics g);

  protected GObject (){
    color = Color.BLACK;
  }

  public void moveTo(double x, double y){
    this.x = x;
    this.y = y;
    repaint();
  }

  public void setColor(Color color){
    this.color = color;
    repaint();
  }

  protected void repaint(){
    if (gc != null) gc.repaint();
  }

  protected double x,y;
  protected Color color;
  protected GCanvas gc;

}
