/* Pravesh Agarwal
 * Feb 6, Thursday, 2020
 * HW2, Q1 Exercise 4 of Chapter 7 found on p.273
 * Construcing a Date class that initializes dates in MDY or DMY form.
 */


public class Date{

  private int dd, yy;
  private Month mm;
  

  public Date(Month mm, int dd, int yy){
    this.dd = dd;
    this.mm=mm;
    this.yy=yy;
  }

  public Date(){
    this(Month.JANUARY, 01, 1900);
  }

  public Date(int dd, Month mm, int yy){
    this(mm, dd, yy);
  }

  public int getDay(){
    return dd;
  }

  public Month getMonth(){
    return mm;
  }
  
  public int getYear(){
    return yy;
  }

  public String toString(){
     return dd+"-"+mm.toString() + "-"+yy;
  }


}
